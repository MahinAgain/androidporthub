# AndroPortHub starter website

A responsive static website for discovering PC/console games on mobile. It works on Android and Windows browsers.

## Preview locally
- Open `index.html` in any modern browser.
- On Android, use your file manager to open the file in Chrome, or transfer the folder to your PC.
- Search, category filters, detail popups, and the demo suggestion form work without a server.

## Publish for free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com
2. Create a new **public** repository named `androporthub` (or another name).
3. Upload `index.html` to the repository root. You can also upload `README.md`.
4. Open repository **Settings → Pages**.
5. Under build/deployment, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then press **Save**.
7. Wait a few minutes. GitHub will show the public site URL in Settings → Pages.

Alternative: Netlify Drop at https://app.netlify.com/drop can publish a folder by drag-and-drop from a PC. For the easiest first publish, GitHub Pages is a good option.

## Important notes
- This is a static starter website. The game catalogue is sample content, not a live database.
- The suggestion form is a front-end demo and does not send or save submissions. Connect a form service or backend to collect real submissions.
- Use official store links and project documentation when adding real downloads. Do not host copyrighted game files without permission.
- The site is not affiliated with game publishers.
